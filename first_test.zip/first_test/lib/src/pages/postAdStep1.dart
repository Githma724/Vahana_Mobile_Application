import 'package:dropdownfield/dropdownfield.dart';
import 'package:first_test/src/pages/profile_page.dart';
import 'package:flutter/material.dart';
import 'package:first_test/src/pages/postAdStep2.dart';

import 'MyHomePage.dart';
import 'categry.dart';

class PostAdStep1Page extends StatefulWidget {
  @override
  _PostAdStep1PageState createState() => _PostAdStep1PageState();
}

class _PostAdStep1PageState extends State<PostAdStep1Page> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text('Post an Ad'),
          backgroundColor: Theme.of(context).primaryColor),
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          padding: EdgeInsets.all(10.0),
          child: Column(
            //mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Text(
                "Step1",
                textAlign: TextAlign.center,
                style: TextStyle(
                  backgroundColor: Colors.greenAccent,
                  fontSize: 22.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                "Name:",
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                textAlign: TextAlign.left,
              ),
              TextField(
                decoration: new InputDecoration(
                  hintText: "Enter Name",
                  hintStyle: new TextStyle(
                      color: Theme.of(context).primaryColor,
                      fontSize: 15.0,
                      fontWeight: FontWeight.bold),
                  fillColor: Colors.white,
                  border: new OutlineInputBorder(
                    borderRadius: new BorderRadius.circular(15.0),
                    borderSide: new BorderSide(),
                  ),
                  //fillColor: Colors.green
                ),
                keyboardType: TextInputType.name,
                style: new TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 15,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                "Mobile Number:",
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                textAlign: TextAlign.left,
              ),
              TextField(
                decoration: new InputDecoration(
                  hintText: "Enter Mobile Number",
                  hintStyle: new TextStyle(
                      color: Theme.of(context).primaryColor,
                      fontSize: 15.0,
                      fontWeight: FontWeight.bold),
                  fillColor: Colors.white,
                  border: new OutlineInputBorder(
                    borderRadius: new BorderRadius.circular(15.0),
                    borderSide: new BorderSide(),
                  ),
                  //fillColor: Colors.green
                ),
                keyboardType: TextInputType.name,
                style: new TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 15,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                "Email:",
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                textAlign: TextAlign.left,
              ),
              TextField(
                decoration: new InputDecoration(
                  hintText: "Enter Email",
                  hintStyle: new TextStyle(
                      color: Theme.of(context).primaryColor,
                      fontSize: 15.0,
                      fontWeight: FontWeight.bold),
                  fillColor: Colors.white,
                  border: new OutlineInputBorder(
                    borderRadius: new BorderRadius.circular(15.0),
                    borderSide: new BorderSide(),
                  ),
                  //fillColor: Colors.green
                ),
                keyboardType: TextInputType.name,
                style: new TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 15,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                "Location:",
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                textAlign: TextAlign.left,
              ),
              DropDownField(
                controller: districtSelected,
                hintText: "Select Vehicle's District",
                hintStyle: TextStyle(
                    color: Theme.of(context).primaryColor,
                    fontSize: 15.0,
                    fontWeight: FontWeight.bold),
                enabled: true,
                textStyle: TextStyle(
                    fontSize: 15.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.blueAccent),
                itemsVisibleInDropdown: 2,
                items: districts,
                //style: TextStyle(color: Colors.blue),
                onValueChanged: (value) {
                  setState(() {
                    selectDistrict = value;
                  });
                },
              ),
              SizedBox(
                height: 10.0,
              ),
              Text(
                "City:",
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                textAlign: TextAlign.left,
              ),
              DropDownField(
                controller: citySelected,
                hintText: "Select Vehicle's City",
                hintStyle: TextStyle(
                  fontSize: 15.0,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).primaryColor,
                ),
                enabled: true,
                textStyle: TextStyle(
                    fontSize: 15.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.blueAccent),
                itemsVisibleInDropdown: 1,
                /*if(selectDistrict=="Matara"){
                  items: mtrcities,
                }*/
                items: mtrcities,
                //style: TextStyle(color: Colors.blue),
                onValueChanged: (value) {
                  setState(() {
                    selectCity = value;
                  });
                },
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      SizedBox.fromSize(
                        size: Size(120, 120), // button width and height
                        child: ClipOval(
                          child: Material(
                            color: Colors.white, // button color
                            child: InkWell(
                              splashColor: Colors.green, // splash color
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => PostAdStep1Page(),
                                    ));
                              }, // button pressed
                              /*child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Icon(
                                    Icons.directions_car,
                                    size: 80,
                                  ), // icon
                                  Text(
                                    "CAR",
                                    style: TextStyle(
                                      fontSize: 13.5,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ), // text
                                ],
                              ),*/
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    width: 190.0,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      SizedBox.fromSize(
                        size: Size(80, 100), // button width and height
                        child: ClipOval(
                          child: Material(
                            color: Colors.white, // button color
                            child: InkWell(
                              splashColor: Colors.green, // splash color
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => PostAdStep2Page(),
                                    ));
                              }, // button pressed
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Icon(
                                    Icons.navigate_next,
                                    size: 60,
                                    color: Theme.of(context).primaryColor,
                                  ), // icon
                                  Text(
                                    "Step2",
                                    style: TextStyle(
                                      fontSize: 15.5,
                                      color: Theme.of(context).primaryColor,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        //currentIndex: currentTab,
        items: [
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => MyHomePage())),
                child: Icon(
                  Icons.home,
                  size: 30,
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => CategoryPage())),
                child: Icon(
                  Icons.add_circle,
                  size: 40,
                  color: Color(0xFF6471BC),
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => ProfilePage())),
                child: Icon(
                  Icons.account_circle,
                  size: 30,
                  color: Color(0xFF6471BC),
                ),
              ),
              title: Text('')),
        ],
      ),
    );
  }
}

final districtSelected = TextEditingController();
final citySelected = TextEditingController();

String selectDistrict = "";
String selectCity = "";
//lIST fOR DISTRICT
List<String> districts = [
  "Anurdhapura",
  "Ampara",
  "Badulla",
  "Batticaloa"
      "Colombo",
  "Galle",
  "Matara",
  "Monaragala",
  "Mullaitivu",
  "Nuwara Eliya",
  "Polonnaruwa",
  "Puttalam",
  "Ratnapura",
  "Trincomalee",
  "Vavuniya"
];

List<String> mtrcities = ["Matara", "Akuressa", "Weligama"];
