import 'package:first_test/src/pages/profile_page.dart';
import 'package:flutter/material.dart';
import 'package:first_test/src/pages/expansionTile.dart';

import 'MyHomePage.dart';
import 'categry.dart';
//import 'package:todoflutter/expansionTile.dart';

class briefAd extends StatefulWidget {
  @override
  _briefAdState createState() => _briefAdState();
}

class _briefAdState extends State<briefAd> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF6471BC),
        title: Text(
          'Category Navigation',
        ),
        centerTitle: true,
        elevation: 0.0,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: RaisedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  Expansiontile()));
                    },
                    child: Text('Categories'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        //currentIndex: currentTab,
        items: [
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => MyHomePage())),
                child: Icon(
                  Icons.home,
                  size: 30,
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => CategoryPage())),
                child: Icon(
                  Icons.add_circle,
                  size: 40,
                  color: Color(0xFF6471BC),
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => ProfilePage())),
                child: Icon(
                  Icons.account_circle,
                  size: 30,
                  color: Color(0xFF6471BC),
                ),
              ),
              title: Text('')),
        ],
      ),
    );
  }
}
