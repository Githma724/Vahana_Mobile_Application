import 'package:flutter/material.dart';
import 'package:first_test/src/widgets/custom_list_tile.dart';
import 'package:first_test/src/widgets/small_button.dart';

class PrfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<PrfilePage> {
  bool turnOnNotification = false;
  bool turnOnLocation = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SizedBox(
                height: 20.0,
              ),
              Card(
                elevation: 3.0,
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Row(
                    children: <Widget>[
                      RaisedButton(
                        color: Theme.of(context).primaryColor,
                        onPressed: () {},
                        child: Row(
                          children: [
                            Icon(
                              Icons.location_on,
                              color: Colors.white,
                            ),
                            SizedBox(
                              width: 15,
                            ),
                            Text(
                              "Location",
                              style: TextStyle(
                                fontSize: 18.0,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ),
                      /*Divider(
                        width: 10.0,
                        color: Colors.white,
                      ),*/
                      SizedBox(
                        width: 40,
                      ),
                      RaisedButton(
                        color: Theme.of(context).primaryColor,
                        onPressed: () {},
                        child: Row(
                          children: [
                            Icon(
                              Icons.local_offer,
                              color: Colors.white,
                            ),
                            SizedBox(
                              width: 15,
                            ),
                            Text(
                              "Brief Ad",
                              style: TextStyle(
                                  fontSize: 18.0,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 30.0,
              ),
              SizedBox(
                height: 20.0,
              ),
              Card(
                elevation: 3.0,
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Column(
                    children: <Widget>[
                      CustomListTile(
                        icon: Icons.battery_charging_full,
                        text: "Model:CK 3154-century 10/2 Amp",
                      ),
                      Divider(
                        height: 10.0,
                        color: Colors.white,
                      ),
                      CustomListTile(
                        icon: Icons.attach_money,
                        text: "Price:Rs.17640",
                      ),
                      Divider(
                        height: 10.0,
                        color: Colors.white,
                      ),
                      CustomListTile(
                        icon: Icons.location_on,
                        text: "Location: Colombo",
                      ),
                      Divider(
                        height: 10.0,
                        color: Colors.white,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          SizedBox(
                            width: 30,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox.fromSize(
                                size: Size(30, 30), // button width and height
                                child: ClipOval(
                                  child: Material(
                                    color: Theme.of(context)
                                        .primaryColor, // button color
                                    child: InkWell(
                                      splashColor: Colors.pink, // splash color
                                      onTap: () {}, // button pressed
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(
                                            Icons.call,
                                            size: 20,
                                            color: Colors.white,
                                          ), // icon
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                          SizedBox(
                            width: 50,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox.fromSize(
                                size: Size(30, 30), // button width and height
                                child: ClipOval(
                                  child: Material(
                                    color: Theme.of(context)
                                        .primaryColor, // button color
                                    child: InkWell(
                                      splashColor: Colors.pink, // splash color
                                      onTap: () {}, // button pressed
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(
                                            Icons.mail,
                                            size: 20,
                                            color: Colors.white,
                                          ), // icon
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                          SizedBox(
                            width: 50,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox.fromSize(
                                size: Size(30, 30), // button width and height
                                child: ClipOval(
                                  child: Material(
                                    color: Theme.of(context)
                                        .primaryColor, // button color
                                    child: InkWell(
                                      splashColor: Colors.pink, // splash color
                                      onTap: () {}, // button pressed
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(
                                            Icons.map,
                                            size: 20,
                                            color: Colors.white,
                                          ), // icon
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                          SizedBox(
                            width: 50,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox.fromSize(
                                size: Size(30, 30), // button width and height
                                child: ClipOval(
                                  child: Material(
                                    color: Theme.of(context)
                                        .primaryColor, // button color
                                    child: InkWell(
                                      splashColor: Colors.pink, // splash color
                                      onTap: () {}, // button pressed
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(
                                            Icons.forum,
                                            size: 20,
                                            color: Colors.white,
                                          ), // icon
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                        ],
                      ),
                      Divider(
                        height: 10.0,
                        color: Colors.white,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 30.0,
              ),
              SizedBox(
                height: 20.0,
              ),
              Card(
                elevation: 3.0,
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Column(
                    children: <Widget>[
                      CustomListTile(
                        icon: Icons.battery_charging_full,
                        text: "Model:CK 3154-century 10/2 Amp",
                      ),
                      Divider(
                        height: 10.0,
                        color: Colors.white,
                      ),
                      CustomListTile(
                        icon: Icons.attach_money,
                        text: "Price:Rs.17640",
                      ),
                      Divider(
                        height: 10.0,
                        color: Colors.white,
                      ),
                      CustomListTile(
                        icon: Icons.location_on,
                        text: "Location: Colombo",
                      ),
                      Divider(
                        height: 10.0,
                        color: Colors.white,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          SizedBox(
                            width: 30,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox.fromSize(
                                size: Size(30, 30), // button width and height
                                child: ClipOval(
                                  child: Material(
                                    color: Theme.of(context)
                                        .primaryColor, // button color
                                    child: InkWell(
                                      splashColor: Colors.pink, // splash color
                                      onTap: () {}, // button pressed
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(
                                            Icons.call,
                                            size: 20,
                                            color: Colors.white,
                                          ), // icon
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                          SizedBox(
                            width: 50,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox.fromSize(
                                size: Size(30, 30), // button width and height
                                child: ClipOval(
                                  child: Material(
                                    color: Theme.of(context)
                                        .primaryColor, // button color
                                    child: InkWell(
                                      splashColor: Colors.pink, // splash color
                                      onTap: () {}, // button pressed
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(
                                            Icons.mail,
                                            size: 20,
                                            color: Colors.white,
                                          ), // icon
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                          SizedBox(
                            width: 50,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox.fromSize(
                                size: Size(30, 30), // button width and height
                                child: ClipOval(
                                  child: Material(
                                    color: Theme.of(context)
                                        .primaryColor, // button color
                                    child: InkWell(
                                      splashColor: Colors.pink, // splash color
                                      onTap: () {}, // button pressed
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(
                                            Icons.map,
                                            size: 20,
                                            color: Colors.white,
                                          ), // icon
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                          SizedBox(
                            width: 50,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox.fromSize(
                                size: Size(30, 30), // button width and height
                                child: ClipOval(
                                  child: Material(
                                    color: Theme.of(context)
                                        .primaryColor, // button color
                                    child: InkWell(
                                      splashColor: Colors.pink, // splash color
                                      onTap: () {}, // button pressed
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(
                                            Icons.forum,
                                            size: 20,
                                            color: Colors.white,
                                          ), // icon
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                        ],
                      ),
                      Divider(
                        height: 10.0,
                        color: Colors.white,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 30.0,
              ),
              SizedBox(
                height: 20.0,
              ),
              Card(
                elevation: 3.0,
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Column(
                    children: <Widget>[
                      CustomListTile(
                        icon: Icons.battery_charging_full,
                        text: "Model:CK 3154-century 10/2 Amp",
                      ),
                      Divider(
                        height: 10.0,
                        color: Colors.white,
                      ),
                      CustomListTile(
                        icon: Icons.attach_money,
                        text: "Price:Rs.17640",
                      ),
                      Divider(
                        height: 10.0,
                        color: Colors.white,
                      ),
                      CustomListTile(
                        icon: Icons.location_on,
                        text: "Location: Colombo",
                      ),
                      Divider(
                        height: 10.0,
                        color: Colors.white,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          SizedBox(
                            width: 30,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox.fromSize(
                                size: Size(30, 30), // button width and height
                                child: ClipOval(
                                  child: Material(
                                    color: Theme.of(context)
                                        .primaryColor, // button color
                                    child: InkWell(
                                      splashColor: Colors.pink, // splash color
                                      onTap: () {}, // button pressed
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(
                                            Icons.call,
                                            size: 20,
                                            color: Colors.white,
                                          ), // icon
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                          SizedBox(
                            width: 50,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox.fromSize(
                                size: Size(30, 30), // button width and height
                                child: ClipOval(
                                  child: Material(
                                    color: Theme.of(context)
                                        .primaryColor, // button color
                                    child: InkWell(
                                      splashColor: Colors.pink, // splash color
                                      onTap: () {}, // button pressed
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(
                                            Icons.mail,
                                            size: 20,
                                            color: Colors.white,
                                          ), // icon
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                          SizedBox(
                            width: 50,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox.fromSize(
                                size: Size(30, 30), // button width and height
                                child: ClipOval(
                                  child: Material(
                                    color: Theme.of(context)
                                        .primaryColor, // button color
                                    child: InkWell(
                                      splashColor: Colors.pink, // splash color
                                      onTap: () {}, // button pressed
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(
                                            Icons.map,
                                            size: 20,
                                            color: Colors.white,
                                          ), // icon
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                          SizedBox(
                            width: 50,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox.fromSize(
                                size: Size(30, 30), // button width and height
                                child: ClipOval(
                                  child: Material(
                                    color: Theme.of(context)
                                        .primaryColor, // button color
                                    child: InkWell(
                                      splashColor: Colors.pink, // splash color
                                      onTap: () {}, // button pressed
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(
                                            Icons.forum,
                                            size: 20,
                                            color: Colors.white,
                                          ), // icon
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                        ],
                      ),
                      Divider(
                        height: 10.0,
                        color: Colors.white,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
