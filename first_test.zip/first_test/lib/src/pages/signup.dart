import 'package:first_test/src/pages/profile_page.dart';
import 'package:flutter/material.dart';
//import 'package:flutter_login_page/pages/main_drawer.dart';
//import 'package:flutter_login_page/pages/test.dart';

import 'MyHomePage.dart';
import 'categry.dart';
import 'login.dart';
import 'main_drawer.dart';

class SignPage extends StatefulWidget {
  @override
  _SignPageState createState() => _SignPageState();
}

class _SignPageState extends State<SignPage> {
  bool _isHidden = true;

  void _toggleVisibility() {
    setState(() {
      _isHidden = !_isHidden;
    });
  }

  @override
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        elevation: 0,
        title: Image.asset(
          'assets/images/my1.jpeg',
          fit: BoxFit.cover,
          height: 50.0,
          width: 70.0,
          alignment: FractionalOffset.center,
        ),
        backgroundColor: Color(0xFF6471BC),
      ),
      drawer: MainDrawer(),
      resizeToAvoidBottomPadding: false,
      body: Container(
        padding:
            EdgeInsets.only(top: 30.0, right: 30.0, left: 30.0, bottom: 7.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            // Text(
            //   'Logo',
            //   style: TextStyle(
            //       fontSize: 50.0,
            //       fontWeight: FontWeight.bold,
            //       fontFamily: "Pacifico"),
            // ),
            // Image.asset(
            //   "assets/images/my1.jpeg",
            //   height: 70.0,
            // ),
            // SizedBox(
            //   height: 20.0,
            // ),
            // ListTile(
            //   leading: Icon(
            //     Icons.home,
            //     size: 30,
            //     color: Colors.black,
            //   ),
            //   title: Text(
            //     "Home",
            //     style: TextStyle(
            //       fontSize: 15,
            //     ),
            //   ),
            // ),
            Text(
              "Sign Up",
              style: TextStyle(
                  fontSize: 27.0,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).primaryColor),
            ),
            SizedBox(
              height: 10.0,
            ),
            buildTextField1(
              "Your Name",
            ),
            SizedBox(
              height: 10.0,
            ),
            buildTextField2("Phone Number"),
            SizedBox(
              height: 10.0,
            ),
            buildTextField("Email"),

            SizedBox(
              height: 10.0,
            ),
            buildTextField("Password"),
            SizedBox(
              height: 10.0,
            ),
            buildTextField("Confirm Password"),
            Container(
              padding: EdgeInsets.only(left: 35),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  ListTile(
                    leading: Icon(
                      Icons.check_box,
                      size: 20,
                      color: Theme.of(context).primaryColor,
                    ),
                    title: Text(
                      "I agree to the Terms and Conditions",
                      style: TextStyle(
                        color: Theme.of(context).primaryColor,
                        //fontSize: 15,
                      ),
                    ),
                  ),
                  // Text(
                  //   "I agree to the Terms and Conditions",
                  //   style: TextStyle(
                  //     color: Theme.of(context).primaryColor,
                  //   ),
                  // ),
                ],
              ),
            ),
            //SizedBox(height: 10.0),
            buildButtonContainer(),
            SizedBox(
                //height: 10.0,
                ),
            Container(
              padding: EdgeInsets.only(left: 100),
              child: Column(
                //mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  ListTile(
                    // leading: Icon(
                    //   Icons.check_box,
                    //   size: 20,
                    //   color: Theme.of(context).primaryColor,
                    // ),
                    title: Text(
                      "Have an account ?  Sign In",
                      style: TextStyle(
                        decoration: TextDecoration.underline,
                        color: Theme.of(context).primaryColor,
                        //fontSize: 15,
                      ),
                    ),
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => LoginPage(),
                          ));
                    },
                  ),
                  // Text(
                  //   "Have an account?",
                  // ),

                  // Text(
                  //   "Sign In",
                  //   style: TextStyle(
                  //     decoration: TextDecoration.underline,
                  //     color: Theme.of(context).primaryColor,
                  //   ),
                  // ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        //currentIndex: currentTab,
        items: [
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => MyHomePage())),
                child: Icon(
                  Icons.home,
                  size: 30,
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => CategoryPage())),
                child: Icon(
                  Icons.add_circle,
                  size: 40,
                  color: Color(0xFF6471BC),
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => ProfilePage())),
                child: Icon(
                  Icons.account_circle,
                  size: 30,
                  color: Color(0xFF6471BC),
                ),
              ),
              title: Text('')),
        ],
      ),
    );
  }

  Widget buildTextField(String hintText) {
    return TextField(
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: TextStyle(
          color: Colors.grey,
          fontSize: 16.0,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20.0),
        ),
        prefixIcon: hintText == 'Email' ? Icon(Icons.email) : Icon(Icons.lock),
        suffixIcon: hintText == "Password"
            ? IconButton(
                onPressed: _toggleVisibility,
                icon: _isHidden
                    ? Icon(Icons.visibility_off)
                    : Icon(Icons.visibility),
              )
            : null,
      ),
      obscureText: hintText == "Password" ? _isHidden : false,
    );
  }

  Widget buildTextField1(String hintText) {
    return TextField(
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: TextStyle(
          color: Colors.grey,
          fontSize: 16.0,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20.0),
        ),
        prefixIcon: Icon(
          Icons.account_circle,
          color: Colors.grey,
          size: 22.0,
        ),
      ),
      obscureText: hintText == "Password" ? _isHidden : false,
    );
  }

  Widget buildTextField2(String hintText) {
    return TextField(
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: TextStyle(
          color: Colors.grey,
          fontSize: 16.0,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20.0),
        ),
        prefixIcon: Icon(
          Icons.phone,
          color: Colors.grey,
          size: 22.0,
        ),
      ),
      obscureText: hintText == "Password" ? _isHidden : false,
    );
  }

  Widget buildButtonContainer() {
    return Container(
        height: 56.0,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(23.0), color: Color(0xFF6471BC),
          //   gradient: LinearGradient(
          //       colors: [Color(0xFFFB415B), Color(0xFFEE5623)],
          //       begin: Alignment.centerRight,
          //       end: Alignment.centerLeft),
        ),
        child: Center(
          child: InkWell(
            child: Text(
              "Sign Up",
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.0,
              ),
            ),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MyHomePage(),
                  ));
            },
          ),
        ));
  }
}
