import 'package:flutter/material.dart';
import 'package:first_test/src/pages/profile_page.dart';

import 'MyHomePage.dart';
import 'categry.dart';

class SettingPage extends StatefulWidget {
  @override
  _SettingPageState createState() => _SettingPageState();
}

class _SettingPageState extends State<SettingPage> {
  @override
  Widget build(BuildContext context) {
    /*Color hexToColor(String code) {
      return new Color(int.parse(code.substring(1, 7), radix: 16) + 0xFF000000);
    }*/

    return Scaffold(
      appBar: AppBar(
          title: Text('Settings'),
          backgroundColor: Theme.of(context).primaryColor),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Container(
            //height: MediaQuery.of(context).size.height,
            //width: MediaQuery.of(context).size.width,
            padding: EdgeInsets.all(25.0),
            child: Column(
                //mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  //new Padding(padding: EdgeInsets.only(top: 140.0)),
                  /*new Text(
                      'Beautiful Flutter TextBox',
                      textAlign: TextAlign.left,
                      style: new TextStyle(
                          color: hexToColor("#F2A03D"), fontSize: 20.0),
                    ),*/
                  //new Padding(padding: EdgeInsets.only(top: 50.0)),
                  SizedBox(
                    height: 20.0,
                  ),
                  new Text(
                    "Name:",
                    style:
                        TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.left,
                  ),
                  new TextFormField(
                    initialValue: "John Doe",
                    decoration: new InputDecoration(
                      //labelText: "CURRENT PASSWORD",
                      fillColor: Colors.redAccent,
                      border: new OutlineInputBorder(
                        borderRadius: new BorderRadius.circular(15.0),
                        borderSide: new BorderSide(),
                      ),

                      //fillColor: Colors.green
                    ),
                    keyboardType: TextInputType.name,
                    style: new TextStyle(
                        fontFamily: "Poppins",
                        fontSize: 15,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 15.0,
                  ),

                  new Text(
                    "Email:",
                    style:
                        TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.left,
                  ),
                  new TextFormField(
                    initialValue: "johnD@gmail.com",
                    decoration: new InputDecoration(
                      //hintText: "Enter Email",

                      fillColor: Colors.white,
                      border: new OutlineInputBorder(
                        borderRadius: new BorderRadius.circular(15.0),
                        borderSide: new BorderSide(),
                      ),
                      //fillColor: Colors.green
                    ),
                    keyboardType: TextInputType.emailAddress,
                    style: new TextStyle(
                        fontFamily: "Poppins",
                        fontSize: 15,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 15.0,
                  ),

                  new Text(
                    "Mobile Number:",
                    style:
                        TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.left,
                  ),
                  new TextFormField(
                    initialValue: "0714777777",
                    decoration: new InputDecoration(
                      hintText: "Contact Number",

                      fillColor: Colors.white,
                      border: new OutlineInputBorder(
                        borderRadius: new BorderRadius.circular(15.0),
                        borderSide: new BorderSide(),
                      ),
                      //fillColor: Colors.green
                    ),
                    keyboardType: TextInputType.number,
                    style: new TextStyle(
                        fontFamily: "Poppins",
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 15,
                  ),

                  SizedBox(
                    width: 140,
                    height: 40.0,
                    child: RaisedButton(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      color: Theme.of(context).primaryColor,
                      child: Text("UPDATE",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 21.0,
                          )),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ProfilePage(),
                            ));
                      },
                    ),
                  ),
                  SizedBox(
                    height: 30.0,
                  ),
                  new Text(
                    "Current Password:",
                    style:
                        TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.left,
                  ),
                  new TextFormField(
                    obscureText: true,
                    decoration: new InputDecoration(
                      hintText: "Enter Current Password",

                      hintStyle: new TextStyle(
                          color: Theme.of(context).primaryColor,
                          fontSize: 15.0,
                          fontWeight: FontWeight.bold),
                      fillColor: Colors.white,
                      border: new OutlineInputBorder(
                        borderRadius: new BorderRadius.circular(15.0),
                        borderSide: new BorderSide(),
                      ),

                      //fillColor: Colors.green
                    ),
                    keyboardType: TextInputType.emailAddress,
                    style: new TextStyle(
                      fontFamily: "Poppins",
                      fontSize: 20,
                    ),
                  ),
                  SizedBox(
                    height: 15.0,
                  ),
                  /*new Text(
                      'Beautiful Flutter TextBox',
                      textAlign: TextAlign.left,
                      style: new TextStyle(
                          color: hexToColor("#F2A03D"), fontSize: 20.0),
                    ),*/
                  new Text(
                    "New Password:",
                    style:
                        TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.left,
                  ),
                  new TextFormField(
                    obscureText: true,
                    decoration: new InputDecoration(
                      hintText: "Enter New Password",

                      hintStyle: new TextStyle(
                          color: Theme.of(context).primaryColor,
                          fontSize: 15.0,
                          fontWeight: FontWeight.bold),
                      fillColor: Colors.white,
                      border: new OutlineInputBorder(
                        borderRadius: new BorderRadius.circular(15.0),
                        borderSide: new BorderSide(),
                      ),
                      //fillColor: Colors.green
                    ),
                    keyboardType: TextInputType.emailAddress,
                    style: new TextStyle(
                      fontFamily: "Poppins",
                      fontSize: 20,
                    ),
                  ),
                  SizedBox(
                    height: 15.0,
                  ),
                  new Text(
                    "Confirm Password:",
                    style:
                        TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.left,
                  ),
                  new TextFormField(
                    obscureText: true,
                    decoration: new InputDecoration(
                      hintText: "ReEnter New Password",

                      hintStyle: new TextStyle(
                          color: Theme.of(context).primaryColor,
                          fontSize: 15.0,
                          fontWeight: FontWeight.bold),
                      fillColor: Colors.white,
                      border: new OutlineInputBorder(
                        borderRadius: new BorderRadius.circular(15.0),
                        borderSide: new BorderSide(),
                      ),
                      //fillColor: Colors.green
                    ),
                    keyboardType: TextInputType.emailAddress,
                    style: new TextStyle(
                      fontFamily: "Poppins",
                      fontSize: 20,
                    ),
                  ),
                  SizedBox(
                    height: 15.0,
                  ),
                  SizedBox(
                    width: 140,
                    height: 40.0,
                    child: RaisedButton(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      color: Theme.of(context).primaryColor,
                      child: Text("UPDATE",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 21.0,
                          )),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ProfilePage(),
                            ));
                      },
                    ),
                  ),
                ])),
      ),
      bottomNavigationBar: BottomNavigationBar(
        //currentIndex: currentTab,
        items: [
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => MyHomePage())),
                child: Icon(
                  Icons.home,
                  size: 30,
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => CategoryPage())),
                child: Icon(
                  Icons.add_circle,
                  size: 40,
                  color: Color(0xFF6471BC),
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => ProfilePage())),
                child: Icon(
                  Icons.account_circle,
                  size: 30,
                  color: Color(0xFF6471BC),
                ),
              ),
              title: Text('')),
        ],
      ),
    );
  }
}
