import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class VehicleAdPage extends StatefulWidget {
  @override
  _VehicleAdPageState createState() => _VehicleAdPageState();
}

class _VehicleAdPageState extends State<VehicleAdPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Vahana App"),
          leading: IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
              onPressed: () {}),
          actions: [
            IconButton(
                icon: Icon(Icons.share, color: Colors.white),
                onPressed: () {
                  _tripEditModalBottomSheet(context);
                }),
            IconButton(
                icon: Icon(Icons.favorite, color: Colors.white),
                onPressed: () {}),
            IconButton(
                icon: Icon(Icons.menu, color: Colors.white), onPressed: () {}),
          ],
        ),
        body: Stack(
          children: [
            Container(
              padding: EdgeInsets.fromLTRB(10, 10, 90, 90),
              child: new Text(
                "NIssan Fb 15 Ex-Saloon",
                style: TextStyle(
                    fontSize: 25,
                    backgroundColor: Colors.yellow,
                    color: Colors.blue,
                    fontWeight: FontWeight.bold),
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(10, 10, 40, 60),
              child: Column(
                children: [
                  Image.asset(
                    'assets/images/car1.jpg',
                    height: 180,
                    width: 120,
                  ),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(140, 10, 40, 60),
              child: Column(
                children: [
                  Image.asset(
                    'assets/images/car1.jpg',
                    height: 180,
                    width: 120,
                  ),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(300, 100, 40, 60),
              child: Column(
                children: [Text("No upload image")],
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(170, 160, 40, 60),
              child: Column(
                children: [
                  FloatingActionButton(
                      onPressed: () => {}, child: Icon(Icons.add_a_photo)),
                ],
              ),
            ),
            Container(
              child: IconButton(
                icon: Icon(
                  Icons.arrow_left,
                ),
                iconSize: 50,
                padding: EdgeInsets.fromLTRB(0, 190, 10, 50),
                onPressed: () {},
              ),
            ),
            Container(
              child: IconButton(
                icon: Icon(Icons.arrow_right),
                iconSize: 50,
                padding: EdgeInsets.fromLTRB(360, 190, 10, 50),
                onPressed: () {},
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(10, 250, 10, 50),
              child: Table(
                border: TableBorder.all(),
                children: [
                  TableRow(children: [
                    Column(children: [
                      Container(
                          padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                          height: 40,
                          width: 200,
                          color: Colors.black,
                          child: Text(
                            'Published Date ',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                            textAlign: TextAlign.center,
                          )),
                    ]),
                    Column(children: [
                      Container(
                        padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                        child: Text(
                          'July 3,2020',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ]),
                  ]),
                  TableRow(children: [
                    Column(children: [
                      Container(
                          padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                          height: 40,
                          width: 200,
                          color: Colors.black,
                          child: Text(
                            'Price',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                            textAlign: TextAlign.center,
                          )),
                    ]),
                    Column(children: [
                      Container(
                        padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                        child: Text(
                          'Rs 2,200,000.00',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, color: Colors.red),
                        ),
                      ),
                    ]),
                  ]),
                  TableRow(children: [
                    Column(children: [
                      Container(
                          padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                          height: 40,
                          width: 200,
                          color: Colors.black,
                          child: Text(
                            'Location',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                            textAlign: TextAlign.center,
                          )),
                    ]),
                    Column(children: [
                      Container(
                        padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                        child: Text(
                          'Colombo',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ]),
                  ]),
                  TableRow(children: [
                    Column(children: [
                      Container(
                          padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                          height: 40,
                          width: 200,
                          color: Colors.black,
                          child: Text(
                            'Brand',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                            textAlign: TextAlign.center,
                          )),
                    ]),
                    Column(children: [
                      Container(
                        padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                        child: Text(
                          'Nisssan',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ]),
                  ]),
                  TableRow(children: [
                    Column(children: [
                      Container(
                          padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                          height: 40,
                          width: 200,
                          color: Colors.black,
                          child: Text(
                            'Model',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                            textAlign: TextAlign.center,
                          )),
                    ]),
                    Column(children: [
                      Container(
                        padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                        child: Text(
                          'FB15',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ]),
                  ]),
                  TableRow(children: [
                    Column(children: [
                      Container(
                          padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                          height: 40,
                          width: 200,
                          color: Colors.black,
                          child: Text(
                            'Condition',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                            textAlign: TextAlign.center,
                          )),
                    ]),
                    Column(children: [
                      Container(
                        padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                        child: Text(
                          'Secondhand/Used',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ]),
                  ]),
                  TableRow(children: [
                    Column(children: [
                      Container(
                          padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                          height: 40,
                          width: 200,
                          color: Colors.black,
                          child: Text(
                            'Fuel Type',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                            textAlign: TextAlign.center,
                          )),
                    ]),
                    Column(children: [
                      Container(
                        padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                        child: Text(
                          'Petrol',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ]),
                  ]),
                ],
              ),
            ),
          ],
        ),
        bottomNavigationBar: BottomAppBar(
          child: new Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                child: IconButton(
                    icon: Icon(Icons.call, color: Colors.blue),
                    onPressed: () => launch("tel:0719457606")),
              ),
              Expanded(
                child: IconButton(
                    icon: Icon(Icons.message, color: Colors.blue),
                    onPressed: () async {
                      const uri = 'sms:0719457606?body=hello%20there';
                      await launch(uri);
                    }),
              ),
              Expanded(
                child: IconButton(
                    icon: Icon(Icons.email, color: Colors.blue),
                    onPressed: () => launch(
                        "mailto:githmaamarasinghe@gmail.com?subject=News&body=New%20plugin")),
              ),
            ],
          ),
        ));
  }

  void _tripEditModalBottomSheet(context) {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext bc) {
          return Container(
              height: 200,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Text(
                          "Share With",
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Column(
                          children: [
                            Container(
                              padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                              child: FlatButton(
                                onPressed: () => {},
                                child: Image.asset(
                                  'assets/images/gmail.jpg',
                                  height: 60,
                                  width: 60,
                                ),
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                              child: Text(
                                "Gmail",
                                textAlign: TextAlign.right,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            Container(
                              padding: EdgeInsets.fromLTRB(70, 0, 0, 0),
                              child: FlatButton(
                                onPressed: () => {},
                                child: Image.asset(
                                  'assets/images/fb.png',
                                  height: 45,
                                  width: 50,
                                ),
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.fromLTRB(70, 0, 0, 0),
                              child: Text(
                                "Facebook",
                                textAlign: TextAlign.right,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            Container(
                              padding: EdgeInsets.fromLTRB(50, 0, 0, 0),
                              child: FlatButton(
                                onPressed: () => {},
                                child: Image.asset(
                                  'assets/images/whatsapp.jpg',
                                  height: 50,
                                  width: 50,
                                ),
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.fromLTRB(50, 0, 0, 0),
                              child: Text(
                                "Whatsapp",
                                textAlign: TextAlign.right,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Column(
                          children: [
                            Container(
                              padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                              child: FlatButton(
                                onPressed: () => {},
                                child: Image.asset(
                                  'assets/images/twitter.png',
                                  height: 50,
                                  width: 50,
                                ),
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                              child: Text(
                                "Twitter",
                                textAlign: TextAlign.right,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            Container(
                              padding: EdgeInsets.fromLTRB(70, 0, 0, 0),
                              child: FlatButton(
                                onPressed: () => {},
                                child: Image.asset(
                                  'assets/images/drive.jpg',
                                  height: 60,
                                  width: 60,
                                ),
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.fromLTRB(70, 0, 0, 0),
                              child: Text(
                                "drive",
                                textAlign: TextAlign.right,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            Container(
                              padding: EdgeInsets.fromLTRB(70, 0, 0, 0),
                              child: IconButton(
                                icon: Icon(Icons.menu),
                                onPressed: () => {},
                                iconSize: 30,
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.fromLTRB(70, 0, 0, 0),
                              child: Text(
                                "More",
                                textAlign: TextAlign.right,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ));
        });
  }
}
