import 'package:first_test/src/pages/MyHomePage.dart';
import 'package:first_test/src/pages/list_view.dart';
import 'package:first_test/src/pages/profile_page.dart';
import 'package:first_test/src/pages/signup.dart';
import 'package:flutter/material.dart';
//import 'package:flutter_login_page/pages/list_view.dart';
//import 'package:flutter_login_page/pages/signup.dart';
//import '../pages/test.dart';
import '../pages/login.dart';

class MainDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(20),
            color: Theme.of(context).primaryColor,
            child: Center(
              child: Column(
                children: [
                  Container(
                    width: 100,
                    height: 100,
                    margin: EdgeInsets.only(top: 30, bottom: 10),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      image: DecorationImage(
                          image: AssetImage(
                            "assets/images/big.jpg",
                          ),
                          fit: BoxFit.fill),
                    ),
                  ),
                  Text(
                    "Johanna Doe",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                    ),
                  ),
                  SizedBox(
                    height: 5.0,
                  ),
                  Text(
                    "johanna@gmail.com",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
          ),
          ListTile(
            leading: Icon(
              Icons.home,
              size: 30,
              color: Colors.black,
            ),
            title: Text(
              "Home",
              style: TextStyle(
                fontSize: 15,
              ),
            ),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MyHomePage(),
                  ));
            },
          ),
          ListTile(
            leading: Icon(
              Icons.person,
              size: 30,
              color: Colors.black,
            ),
            title: Text(
              "My Account",
              style: TextStyle(
                fontSize: 15,
              ),
            ),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProfilePage(),
                  ));
            },
          ),
          ListTile(
            leading: Icon(
              Icons.favorite,
              size: 30,
              color: Colors.black,
            ),
            title: Text(
              "Wish List",
              style: TextStyle(
                fontSize: 15,
              ),
            ),
            onTap: null,
          ),
          ListTile(
            leading: Icon(
              Icons.event_note,
              size: 30,
              color: Colors.black,
            ),
            title: Text(
              "My ads",
              style: TextStyle(
                fontSize: 15,
              ),
            ),
            onTap: null,
          ),
          SizedBox(
            height: 200,
          ),
          ListTile(
            leading: Icon(
              Icons.indeterminate_check_box,
              size: 30,
              color: Colors.black,
            ),
            title: Text(
              "Logout",
              style: TextStyle(
                fontSize: 15,
              ),
            ),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => LoginPage(),
                  ));
            },
          ),
        ],
      ),
    );
  }
}
