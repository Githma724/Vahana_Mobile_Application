import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
//import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'MyHomePage.dart';
import 'briefAd.dart';
import 'package:first_test/src/models/briefDetails.dart';
//import 'package:todoflutter/models/briefDetails.dart';

class briefADs extends StatefulWidget {
  @override
  _briefADsState createState() => _briefADsState();
}

class _briefADsState extends State<briefADs> {
  int selectedIndex = 1;
  int index = 0;
  int theriGroupVakue = 0;
  int currentTab = 0;

  final Map<int, Widget> logoWidgets = const <int, Widget>{
    0: Text("Location"),
    1: Text("Category")
  };
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: <Widget>[
          AppBar(
            centerTitle: true,
            backgroundColor: Color(0xFF6471BC),
            elevation: 0,
            automaticallyImplyLeading: false,
            title: Image.asset(
              'assets/images/logo.jpg',
              fit: BoxFit.cover,
              height: 50.0,
              width: 70.0,
              alignment: FractionalOffset.center,
            ),
          ),
          Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                Expanded(
                  child: Container(
                      //width: double.infinity,
                      margin: EdgeInsets.only(
                          left: 10, top: 10, right: 1, bottom: 10),
                      child: TextField(
                        decoration: InputDecoration(
                            labelText: 'Search Vehicles',
                            filled: true,
                            fillColor: Colors.grey[300],
                            enabledBorder: UnderlineInputBorder(
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(10),
                                  topRight: Radius.circular(10),
                                  bottomLeft: Radius.circular(10),
                                  bottomRight: Radius.circular(10)),
                              borderSide: BorderSide(color: Colors.black),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(10),
                                  topRight: Radius.circular(10),
                                  bottomLeft: Radius.circular(10),
                                  bottomRight: Radius.circular(10)),
                              borderSide: BorderSide(color: Colors.black),
                            )),
                      )),
                ),
                GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedIndex = index;
                    });
                    print(index);
                  },
                  child: Container(
                      height: 57,
                      width: 60,
                      margin: EdgeInsets.only(
                          left: 15, top: 3, right: 15, bottom: 5),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.black, width: 1.0),
                        color: selectedIndex == index
                            ? Color(0xFF6471BC)
                            : Colors.white,
                        shape: BoxShape.rectangle,
                      ),
                      child: Icon(Icons.tune, size: 40.0)),
                ),
              ]),
          Row(
            children: <Widget>[
              Container(
                child: SizedBox(
                  height: 1,
                  width: 15.0,
                ),
              ),
              Expanded(
                child: CupertinoSegmentedControl(
                  selectedColor: Color(0xFF6471BC),
                  borderColor: Color(0xFF6471BC),
                  groupValue: theriGroupVakue,
                  onValueChanged: (changeFromGroupValue) {
                    setState(() {
                      theriGroupVakue = changeFromGroupValue;
                    });
                    if (theriGroupVakue == 1) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => briefAd()),
                      );
                    }
                  },
                  children: logoWidgets,
                ),
              ),
              SizedBox(height: 1.0, width: 1.0),
              const Padding(padding: EdgeInsets.only(top: 1, bottom: 10)),
            ],
          ),
          Expanded(
            child: ListView.builder(
              itemCount: detailsBrief.length,
              itemBuilder: (BuildContext context, int index) {
                details activity = detailsBrief[index];
                return Stack(
                  children: <Widget>[
                    Container(
                      margin: EdgeInsets.fromLTRB(40.0, 5.0, 20.0, 5.0),
                      height: 170.0,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 5, 10, 10),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  activity.name,
                                  style: TextStyle(
                                      fontSize: 22.0,
                                      fontWeight: FontWeight.bold),
                                ),
                                Text(
                                  activity.price,
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(0, 10, 0, 0),
                                  child: Text(
                                    activity.condition,
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w500),
                                  ),
                                ),
                                Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(0, 10, 0, 30),
                                  child: Text(
                                    activity.description,
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w500),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 2,
                                  ),
                                ),
                                Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(0, 0, 0, 0),
                                  child: Text(
                                    activity.location,
                                    textAlign: TextAlign.center,
                                    style:
                                        TextStyle(fontStyle: FontStyle.italic),
                                  ),
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 40,
                      top: 5,
                      bottom: 5,
                      child: ClipRRect(
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10),
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10)),
                      ),
                    )
                  ],
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentTab,
        items: [
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => MyHomePage())),
                child: Icon(
                  Icons.home,
                  size: 30,
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: Icon(
                Icons.add_circle,
                size: 30,
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: Icon(
                Icons.account_circle,
                size: 30,
              ),
              title: Text(''))
        ],
      ),
    );
  }
}
