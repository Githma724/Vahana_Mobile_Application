import 'package:first_test/src/pages/list_view.dart';
import 'package:first_test/src/pages/profile_page.dart';
import 'package:first_test/src/pages/signup.dart';
import 'package:flutter/material.dart';
//import 'package:flutter_login_page/pages/list_view.dart';
//import 'package:flutter_login_page/pages/main_drawer.dart';
//import 'package:flutter_login_page/pages/signup.dart';

import 'MyHomePage.dart';
import 'categry.dart';
import 'main_drawer.dart';
//import 'test.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool _isHidden = true;

  void _toggleVisibility() {
    setState(() {
      _isHidden = !_isHidden;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        elevation: 0,
        title: Image.asset(
          'assets/images/my1.jpeg',
          fit: BoxFit.cover,
          height: 50.0,
          width: 70.0,
          alignment: FractionalOffset.center,
        ),
        backgroundColor: Color(0xFF6471BC),
      ),
      drawer: MainDrawer(),
      resizeToAvoidBottomPadding: false,
      body: Container(
        padding:
            EdgeInsets.only(top: 50.0, right: 30.0, left: 30.0, bottom: 10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            // Text(
            //   'Logo',
            //   style: TextStyle(
            //       fontSize: 50.0,
            //       fontWeight: FontWeight.bold,
            //       fontFamily: "Pacifico"),
            // ),
            // Image.asset(
            //   "assets/images/my1.jpeg",
            //   height: 70.0,
            // ),
            SizedBox(
              height: 30.0,
            ),
            Text(
              "Sign In",
              style: TextStyle(
                  fontSize: 32.0,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).primaryColor),
            ),
            SizedBox(
              height: 40.0,
            ),
            buildTextField("Email"),
            SizedBox(
              height: 20.0,
            ),
            buildTextField("Password"),
            SizedBox(
              height: 20.0,
            ),
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  Text(
                    "Forgotten Password?",
                    style: TextStyle(
                      decoration: TextDecoration.underline,
                      color: Theme.of(context).primaryColor,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 50.0),
            buildButtonContainer(),
            SizedBox(
              height: 10.0,
            ),
            Container(
              padding: EdgeInsets.only(left: 75),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    ListTile(
                      title: Text(
                        "Don't have an account ?  Sign Up",
                        style: TextStyle(
                          decoration: TextDecoration.underline,
                          color: Theme.of(context).primaryColor,
                          //fontSize: 15,
                        ),
                      ),
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => SignPage(),
                            ));
                      },
                    ),
                    // Text("Don't have an account?"),
                    // SizedBox(
                    //   width: 10.0,
                    // ),
                    // Text("Sign up",
                    //     style: TextStyle(
                    //       decoration: TextDecoration.underline,
                    //       color: Theme.of(context).primaryColor,
                    //     )),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        //currentIndex: currentTab,
        items: [
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => MyHomePage())),
                child: Icon(
                  Icons.home,
                  size: 30,
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => CategoryPage())),
                child: Icon(
                  Icons.add_circle,
                  size: 40,
                  color: Color(0xFF6471BC),
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => ProfilePage())),
                child: Icon(
                  Icons.account_circle,
                  size: 30,
                  color: Color(0xFF6471BC),
                ),
              ),
              title: Text('')),
        ],
      ),
    );
  }

  Widget buildTextField(String hintText) {
    return TextField(
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: TextStyle(
          color: Colors.grey,
          fontSize: 16.0,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20.0),
        ),
        prefixIcon: hintText == "Email" ? Icon(Icons.email) : Icon(Icons.lock),
        suffixIcon: hintText == "Password"
            ? IconButton(
                onPressed: _toggleVisibility,
                icon: _isHidden
                    ? Icon(Icons.visibility_off)
                    : Icon(Icons.visibility),
              )
            : null,
      ),
      obscureText: hintText == "Password" ? _isHidden : false,
    );
  }

  Widget buildButtonContainer() {
    return Container(
        height: 56.0,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(23.0), color: Color(0xFF6471BC),
          //   gradient: LinearGradient(
          //       colors: [Color(0xFFFB415B), Color(0xFFEE5623)],
          //       begin: Alignment.centerRight,
          //       end: Alignment.centerLeft),
        ),
        child: Center(
          child: InkWell(
            child: Text(
              "Continue",
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.0,
              ),
            ),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MyHomePage(),
                  ));
            },
          ),
        ));
  }
}
