import 'package:dropdownfield/dropdownfield.dart';
import 'package:first_test/src/pages/profile_page.dart';
import 'package:flutter/material.dart';
import 'package:first_test/src/pages/postAdStep1.dart';
import 'package:first_test/src/pages/postAdStep3.dart';

import 'MyHomePage.dart';
import 'categry.dart';

class PostAdStep2Page extends StatefulWidget {
  @override
  _PostAdStep2PageState createState() => _PostAdStep2PageState();
}

class _PostAdStep2PageState extends State<PostAdStep2Page> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text('Post an Ad'),
          backgroundColor: Theme.of(context).primaryColor),
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          padding: EdgeInsets.all(10.0),
          child: Column(
            //mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Text(
                "Step2",
                textAlign: TextAlign.center,
                style: TextStyle(
                  backgroundColor: Colors.greenAccent,
                  fontSize: 22.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                "Brand:",
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                textAlign: TextAlign.left,
              ),
              TextField(
                decoration: new InputDecoration(
                  hintText: "Enter Brand",
                  hintStyle: new TextStyle(
                      color: Theme.of(context).primaryColor,
                      fontSize: 15.0,
                      fontWeight: FontWeight.bold),
                  fillColor: Colors.white,
                  border: new OutlineInputBorder(
                    borderRadius: new BorderRadius.circular(15.0),
                    borderSide: new BorderSide(),
                  ),
                  //fillColor: Colors.green
                ),
                keyboardType: TextInputType.name,
                style: new TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 15,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                "Transmission:",
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                textAlign: TextAlign.left,
              ),
              DropDownField(
                controller: transmissionSelected,
                hintText: "Select Vehicle's Transmission",
                hintStyle: TextStyle(
                    color: Theme.of(context).primaryColor,
                    fontSize: 15.0,
                    fontWeight: FontWeight.bold),
                enabled: true,
                textStyle: TextStyle(
                    fontSize: 15.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.blueAccent),
                itemsVisibleInDropdown: 2,
                items: transmission,
                //style: TextStyle(color: Colors.blue),
                onValueChanged: (value) {
                  setState(() {
                    selectTransmission = value;
                  });
                },
              ),
              SizedBox(
                height: 10.0,
              ),
              Text(
                "Condition:",
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                textAlign: TextAlign.left,
              ),
              DropDownField(
                controller: conditionSelected,
                hintText: "Select Vehicle's Condition",
                hintStyle: TextStyle(
                  fontSize: 15.0,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).primaryColor,
                ),
                enabled: true,
                textStyle: TextStyle(
                    fontSize: 15.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.blueAccent),
                itemsVisibleInDropdown: 2,
                /*if(selectDistrict=="Matara"){
                  items: mtrcities,
                }*/
                items: condition,
                //style: TextStyle(color: Colors.blue),
                onValueChanged: (value) {
                  setState(() {
                    selectCondition = value;
                  });
                },
              ),
              SizedBox(
                height: 10.0,
              ),
              Text(
                "Manufacture Year:",
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                textAlign: TextAlign.left,
              ),
              DropDownField(
                controller: yearSelected,
                hintText: "Select Vehicle's Manufacture Year",
                hintStyle: TextStyle(
                  fontSize: 15.0,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).primaryColor,
                ),
                enabled: true,
                textStyle: TextStyle(
                    fontSize: 15.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.blueAccent),
                itemsVisibleInDropdown: 2,
                /*if(selectDistrict=="Matara"){
                  items: mtrcities,
                }*/
                items: year,
                //style: TextStyle(color: Colors.blue),
                onValueChanged: (value) {
                  setState(() {
                    selectYear = value;
                  });
                },
              ),
              SizedBox(
                height: 10.0,
              ),
              Text(
                "Price:",
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                textAlign: TextAlign.left,
              ),
              TextField(
                decoration: new InputDecoration(
                  hintText: "Enter Price",
                  hintStyle: new TextStyle(
                      color: Theme.of(context).primaryColor,
                      fontSize: 15.0,
                      fontWeight: FontWeight.bold),
                  fillColor: Colors.white,
                  border: new OutlineInputBorder(
                    borderRadius: new BorderRadius.circular(15.0),
                    borderSide: new BorderSide(),
                  ),
                  //fillColor: Colors.green
                ),
                keyboardType: TextInputType.name,
                style: new TextStyle(
                  fontFamily: "Poppins",
                  fontSize: 15,
                ),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      SizedBox.fromSize(
                        size: Size(80, 100), // button width and height
                        child: ClipOval(
                          child: Material(
                            color: Colors.white, // button color
                            child: InkWell(
                              splashColor: Colors.green, // splash color
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => PostAdStep1Page(),
                                    ));
                              }, // button pressed
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Icon(
                                    Icons.navigate_before,
                                    size: 60,
                                    color: Theme.of(context).primaryColor,
                                  ), // icon
                                  Text(
                                    "Step1",
                                    style: TextStyle(
                                      fontSize: 15.5,
                                      color: Theme.of(context).primaryColor,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    width: 220.0,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      SizedBox.fromSize(
                        size: Size(80, 100), // button width and height
                        child: ClipOval(
                          child: Material(
                            color: Colors.white, // button color
                            child: InkWell(
                              splashColor: Colors.green, // splash color
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => PostAdStep3Page(),
                                    ));
                              }, // button pressed
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Icon(
                                    Icons.navigate_next,
                                    size: 60,
                                    color: Theme.of(context).primaryColor,
                                  ), // icon
                                  Text(
                                    "Step3",
                                    style: TextStyle(
                                      fontSize: 15.5,
                                      color: Theme.of(context).primaryColor,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        //currentIndex: currentTab,
        items: [
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => MyHomePage())),
                child: Icon(
                  Icons.home,
                  size: 30,
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => CategoryPage())),
                child: Icon(
                  Icons.add_circle,
                  size: 40,
                  color: Color(0xFF6471BC),
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => ProfilePage())),
                child: Icon(
                  Icons.account_circle,
                  size: 30,
                  color: Color(0xFF6471BC),
                ),
              ),
              title: Text('')),
        ],
      ),
    );
  }
}

final transmissionSelected = TextEditingController();
final conditionSelected = TextEditingController();
final yearSelected = TextEditingController();

String selectTransmission = "";
String selectCondition = "";
String selectYear = "";
//lIST fOR DISTRICT
List<String> transmission = ["Auto", "Manual"];

List<String> condition = ["New", "Recondition"];

List<String> year = ["2015", "2016", "2017", "2018", "2019", "2020"];
