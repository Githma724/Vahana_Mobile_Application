import 'package:first_test/src/pages/profile_page.dart';
import 'package:flutter/material.dart';

import 'MyHomePage.dart';
import 'categry.dart';
import 'main_drawer.dart';
//import 'package:flutter_login_page/pages/main_drawer.dart';
//import 'package:flutter_login_page/pages/test.dart';

class Category extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        title: Text('Spare parts & Services'),
        backgroundColor: Color(0xFF6471BC),
      ),
      drawer: MainDrawer(),
      body: Stack(
        children: [
          //Padding(padding: EdgeInsets.only(top: 50.0)),
          Container(
            padding: const EdgeInsets.only(top: 30.0, left: 15, right: 15),
            height: 80.0,
            width: double.infinity,
            //color: Colors.white,
            child: Material(
              elevation: 1.0,
              borderRadius: BorderRadius.circular(15),
              color: Colors.white70,
              child: TextFormField(
                decoration: InputDecoration(
                    border: InputBorder.none,
                    prefixIcon: Icon(
                      Icons.search,
                      color: Colors.grey,
                      size: 22.0,
                    ),
                    contentPadding:
                        EdgeInsets.only(left: 30, top: 15, bottom: 10),
                    hintText: 'Search',
                    hintStyle: TextStyle(color: Colors.grey)),
              ),
            ),
          ),
          SizedBox(
            height: 25.0,
          ),
          Padding(
            padding: EdgeInsets.only(left: 15.0, right: 15.0),
            // child: Material(
            //   elevation: 5.0,
            //   borderRadius: BorderRadius.circular(25),
            //   child: TextFormField(
            //     decoration: InputDecoration(
            //         border: InputBorder.none,
            //         prefixIcon: Icon(
            //           Icons.search,
            //           color: Colors.grey,
            //           size: 30.0,
            //         ),
            //         contentPadding:
            //             EdgeInsets.only(left: 20, top: 15, bottom: 10),
            //         hintText: 'Search',
            //         hintStyle: TextStyle(color: Colors.grey)),
            //   ),
            // ),
          ),
          Container(
            //width: MediaQuery.of(context).size.width * 0.45,
            padding: const EdgeInsets.only(top: 100.0),
            child: ListView.builder(
              itemBuilder: (BuildContext context, int index) {
                return new StuffInTiles(listOfTiles[index]);
              },
              itemCount: listOfTiles.length,
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        //currentIndex: currentTab,
        items: [
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => MyHomePage())),
                child: Icon(
                  Icons.home,
                  size: 30,
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => CategoryPage())),
                child: Icon(
                  Icons.add_circle,
                  size: 40,
                  color: Color(0xFF6471BC),
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => ProfilePage())),
                child: Icon(
                  Icons.account_circle,
                  size: 30,
                  color: Color(0xFF6471BC),
                ),
              ),
              title: Text('')),
        ],
      ),
    );
  }
}

class StuffInTiles extends StatelessWidget {
  final MyTile myTile;
  StuffInTiles(this.myTile);

  @override
  Widget build(BuildContext context) {
    return _buildTiles(myTile);
  }

  Widget _buildTiles(MyTile t) {
    if (t.children.isEmpty)
      return new ListTile(
          //dense: true,

          enabled: true,
          isThreeLine: false,
          onLongPress: () => print("long press"),
          onTap: () => print("tap"),
          //subtitle: new Text("Subtitle"),
          //leading: new Text("Leading"),
          //selected: true,
          //trailing: new Text("trailing"),
          title: new Text(t.title));

    return new ExpansionTile(
      key: new PageStorageKey<int>(3),
      title: new Text(t.title),
      children: t.children.map(_buildTiles).toList(),
    );
  }
}

class MyTile {
  String title;
  List<MyTile> children;
  MyTile(this.title, [this.children = const <MyTile>[]]);
}

List<MyTile> listOfTiles = <MyTile>[
  new MyTile(
    'Spare Parts',
    <MyTile>[
      new MyTile(
        'Batteries & Charging Equipment',
        <MyTile>[
          MyTile(
            'Batteries',
          ),
          new MyTile('Charging Equipment'),
          //new MyTile('Poodle'),
        ],
      ),
      new MyTile('Engines'),
      new MyTile('Tyres'),
    ],
  ),
  new MyTile(
    'Services',
    <MyTile>[
      new MyTile('Automobile A/C'),
      new MyTile('Motor Vehicle Distributors'),
      new MyTile('Motorcar Parts Suppliers- Wholesale'),
    ],
  ),
];
