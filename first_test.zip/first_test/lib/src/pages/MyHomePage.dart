import 'package:first_test/src/pages/profile_page.dart';
import 'package:first_test/src/pages/vehicleAd.dart';
import 'package:flutter/material.dart';
import 'package:first_test/src/pages/briefAd.dart';
//import 'package:first_test/src/pages/filtercar.dart';
import 'package:first_test/src/models/activity_model.dart';
//import 'package:todoflutter/filtercar.dart';
import 'package:flutter/cupertino.dart';
import 'categry.dart';
import 'main_drawer.dart';
//import 'package:todoflutter/models/activity_model.dart';

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int selectedIndex = 1;
  int index = 0;
  int theriGroupVakue = 0;
  int currentTab = 0;

  final Map<int, Widget> logoWidgets = const <int, Widget>{
    0: Text("Location"),
    1: Text("Category")
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: MainDrawer(),
      body: Column(
        children: <Widget>[
          AppBar(
            centerTitle: true,
            backgroundColor: Color(0xFF6471BC),
            elevation: 0,
            //automaticallyImplyLeading: false,
            title: Image.asset(
              'assets/images/logo.jpg',
              fit: BoxFit.cover,
              height: 50.0,
              width: 70.0,
              alignment: FractionalOffset.center,
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              Expanded(
                child: Container(
                    //width: double.infinity,
                    margin: EdgeInsets.only(
                        left: 10, top: 10, right: 1, bottom: 10),
                    child: TextField(
                      decoration: InputDecoration(
                          labelText: 'Search Vehicles',
                          filled: true,
                          fillColor: Colors.grey[300],
                          enabledBorder: UnderlineInputBorder(
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10),
                                bottomLeft: Radius.circular(10),
                                bottomRight: Radius.circular(10)),
                            borderSide: BorderSide(color: Colors.black),
                          ),
                          focusedBorder: UnderlineInputBorder(
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10),
                                bottomLeft: Radius.circular(10),
                                bottomRight: Radius.circular(10)),
                            borderSide: BorderSide(color: Colors.black),
                          )),
                    )),
              ),
              GestureDetector(
                onTap: () {
                  setState(() {
                    selectedIndex = index;
                  });
                  print(index);
                },
                child: Container(
                    height: 57,
                    width: 60,
                    margin:
                        EdgeInsets.only(left: 15, top: 3, right: 15, bottom: 5),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black, width: 1.0),
                      color: selectedIndex == index
                          ? Color(0xFF6471BC)
                          : Colors.white,
                      shape: BoxShape.rectangle,
                    ),
                    child: Icon(Icons.tune, size: 30.0)),
              ),
            ],
          ),
          Row(
            children: <Widget>[
              Container(
                child: SizedBox(
                  height: 1,
                  width: 15.0,
                ),
              ),
              Expanded(
                child: CupertinoSegmentedControl(
                  selectedColor: Color(0xFF6471BC),
                  borderColor: Color(0xFF6471BC),
                  groupValue: theriGroupVakue,
                  onValueChanged: (changeFromGroupValue) {
                    setState(() {
                      theriGroupVakue = changeFromGroupValue;
                    });
                    if (theriGroupVakue == 1) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => briefAd()),
                      );
                    }
                  },
                  children: logoWidgets,
                ),
              ),
              SizedBox(height: 1.0, width: 1.0),
              const Padding(padding: EdgeInsets.only(top: 1, bottom: 10)),
            ],
          ),
          Expanded(
            child: ListView.builder(
              itemCount: activities.length,
              itemBuilder: (BuildContext context, int index) {
                Activity activity = activities[index];
                return Stack(
                  children: <Widget>[
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => VehicleAdPage(),
                            ));
                      },
                      child: Container(
                        margin: EdgeInsets.fromLTRB(40.0, 5.0, 20.0, 5.0),
                        height: 170.0,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.grey[300],
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(150, 20, 20, 20),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    activity.name,
                                    style: TextStyle(
                                        fontSize: 18.0,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Text(
                                    activity.price,
                                    style: TextStyle(fontSize: 20),
                                  ),
                                  Text(
                                    activity.location,
                                    textAlign: TextAlign.center,
                                    style:
                                        TextStyle(fontStyle: FontStyle.italic),
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 40,
                      top: 5,
                      bottom: 5,
                      child: ClipRRect(
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10),
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10)),
                        child: Image(
                          width: 145,
                          image: AssetImage(activity.imageURL),
                          fit: BoxFit.cover,
                        ),
                      ),
                    )
                  ],
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentTab,
        items: [
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => MyHomePage())),
                child: Icon(
                  Icons.home,
                  size: 30,
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => CategoryPage())),
                child: Icon(
                  Icons.add_circle,
                  size: 40,
                  color: Color(0xFF6471BC),
                ),
              ),
              title: Text('')),
          BottomNavigationBarItem(
              icon: GestureDetector(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => ProfilePage())),
                child: Icon(
                  Icons.account_circle,
                  size: 30,
                  color: Color(0xFF6471BC),
                ),
              ),
              title: Text('')),
        ],
      ),
    );
  }
}
