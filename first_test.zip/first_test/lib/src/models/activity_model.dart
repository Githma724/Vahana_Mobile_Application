class Activity {
  String imageURL;
  String name;
  String price;
  String location;

  Activity({
    this.imageURL,
    this.name,
    this.price,
    this.location,
  });
}

final List<Activity> activities = [
  Activity(
      imageURL: 'assets/images/benz.jpg',
      name: 'Benz CLA 300 2014',
      price: 'Rs.9,700,000',
      location: 'Colombo,colombo'),
  Activity(
      imageURL: 'assets/images/Front.jpg',
      name: 'Toyota Aqua 2015',
      price: 'Rs.4,600,000',
      location: 'Colombo,colombo'),
  Activity(
      imageURL: 'assets/images/montero.jpg',
      name: 'Mitsubishi Montero DHi 2004',
      price: 'Rs.6,800,000',
      location: 'Malabe,colombo'),
  Activity(
      imageURL: 'assets/images/Premio.jpg',
      name: 'Toyota Premio 2018',
      price: 'Rs.8,900,000',
      location: 'Matara,Matara'),
  Activity(
      imageURL: 'assets/images/bmw.jpg',
      name: 'BMW R1200 2016',
      price: 'Rs.2,100,000',
      location: 'Colombo 3,Colombo'),
];
