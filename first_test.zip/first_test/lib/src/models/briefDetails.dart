class details {
  String name;
  String condition;
  String description;
  String price;
  String location;

  details({
    this.name,
    this.condition,
    this.description,
    this.price,
    this.location,
  });
}

final List<details> detailsBrief = [
  details(
      name: 'Toyota Vitz 2020',
      condition: 'Condition : Brand New',
      description:
          'Mileage - 0KM, Power Steering, Unregistered, 5 Years warranty',
      price: 'Rs.4,700,000',
      location: 'Colombo,colombo'),
  details(
      name: 'Mazda RX-8',
      condition: 'Condition : Used',
      description:
          'Mileage - 54000KM, Power Steering, Third Owner, Mint Condition',
      price: 'Rs.3,700,000',
      location: 'Panadura,colombo'),
  details(
      name: 'BMW Z4 2017',
      condition: 'Condition : Reconditioned',
      description:
          'Mileage - 5600KM, Power Steering, Unregistered, 3 Years warranty, Imported from Europe',
      price: 'Rs.9,300,000',
      location: 'Colombo,colombo'),
  details(
      name: 'Toyota Aqua 2020',
      condition: 'Condition : Brand New',
      description:
          'Mileage - 0KM, Power Steering, Unregistered, 5 Years warranty',
      price: 'Rs.6,550,000',
      location: 'Malabe,colombo'),
];
